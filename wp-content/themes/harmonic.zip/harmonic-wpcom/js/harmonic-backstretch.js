(function($) {

	$(document).ready(function() {
    	$("#custom-header").backstretch([BackStretchImg.src],{duration:3000,fade:750});
	});

})(jQuery);
